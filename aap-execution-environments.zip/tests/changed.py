#!/usr/bin/env python3
"""Qué familias hay que construir, en JSON. Uso: changed.py <ref-base>
- cambió algo en ee/<familia>/            → esa familia
- cambió su versión en ee/versions.yml   → esa familia
- cambió ci/, tests/ o .github/           → las 4 (afecta a todas las imágenes)"""
import json, subprocess, sys, yaml

FAMS = ["linux", "openshift", "api", "windows"]
base = sys.argv[1] if len(sys.argv) > 1 and sys.argv[1] else "HEAD~1"
try:
    changed = subprocess.check_output(["git", "diff", "--name-only", f"{base}...HEAD"], text=True).split()
except subprocess.CalledProcessError:
    print(json.dumps(FAMS)); sys.exit(0)
if any(p.startswith(("ci/", "tests/", ".github/")) for p in changed):
    print(json.dumps(FAMS)); sys.exit(0)
out = {p.split("/")[1] for p in changed if p.startswith("ee/") and p.count("/") >= 2 and p.split("/")[1] in FAMS}
if "ee/versions.yml" in changed:
    now = yaml.safe_load(open("ee/versions.yml"))
    try:
        before = yaml.safe_load(subprocess.check_output(["git", "show", f"{base}:ee/versions.yml"], text=True)) or {}
    except subprocess.CalledProcessError:
        before = {}
    out |= {f for f in FAMS if str(now.get(f)) != str(before.get(f))}
print(json.dumps([f for f in FAMS if f in out]))
