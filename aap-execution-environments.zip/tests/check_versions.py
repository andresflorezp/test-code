#!/usr/bin/env python3
"""Si cambió algo en ee/<familia>/ respecto a la rama base, su versión en ee/versions.yml tiene que subir.
Uso: check_versions.py <ref-base>  (p. ej. origin/main)"""
import subprocess, sys, yaml

base = sys.argv[1] if len(sys.argv) > 1 else "origin/main"
now = yaml.safe_load(open("ee/versions.yml"))
try:
    before = yaml.safe_load(subprocess.check_output(["git", "show", f"{base}:ee/versions.yml"], text=True))
except subprocess.CalledProcessError:
    print("ee/versions.yml no existe en la base: primera versión, ok"); sys.exit(0)
changed = subprocess.check_output(["git", "diff", "--name-only", f"{base}...HEAD", "--", "ee/", "ci/"], text=True).split()
fams = {p.split("/")[1] for p in changed if p.startswith("ee/") and p.count("/") >= 2}
if any(p.startswith("ci/") for p in changed):
    fams |= set(now)            # cambiar la imagen de CI cambia las 4 imágenes -ci
bad = []
for f in sorted(fams):
    v0, v1 = str(before.get(f, "0.0.0")), str(now.get(f, ""))
    key = lambda v: tuple(int(x) for x in v.split("."))
    if not v1 or key(v1) <= key(v0):
        bad.append(f"{f}: cambió ee/{f}/ pero la versión sigue en {v1} (antes {v0}). Súbela en ee/versions.yml")
print("\n".join(bad) or f"versiones ok ({', '.join(sorted(fams)) or 'ninguna familia cambió'})")
sys.exit(1 if bad else 0)
