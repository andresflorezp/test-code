#!/usr/bin/env bash
# Prueba rápida de una imagen ya construida: collections, librerías de Python y binarios.
# Uso: tests/smoke.sh <familia> <imagen>
set -euo pipefail
fam="$1"; img="$2"
read_list() { python3 -c "import yaml,sys;print(' '.join(yaml.safe_load(open('tests/expect.yml'))['$fam']['$1']))"; }
cols=$(read_list collections); pys=$(read_list python); bins=$(read_list bin)

echo "== $img"
podman run --rm "$img" ansible --version | head -1
podman run --rm "$img" ansible-runner --version

have=$(podman run --rm "$img" ansible-galaxy collection list --format json | python3 -c "import json,sys;d=json.load(sys.stdin);print(' '.join(c for p in d.values() for c in p))")
for c in $cols; do grep -qw "$c" <<<"$have" || { echo "FALTA la collection $c"; exit 1; }; done
echo "collections ok: $cols"

for p in $pys; do podman run --rm "$img" python3 -c "import $p" || { echo "FALTA la librería de Python $p"; exit 1; }; done
echo "python ok: $pys"

for b in $bins; do podman run --rm "$img" sh -c "command -v $b >/dev/null" || { echo "FALTA el binario $b"; exit 1; }; done
[ -n "$bins" ] && echo "binarios ok: $bins"

# corre un playbook de verdad dentro del EE
podman run --rm -v "$PWD/tests:/runner/t:Z" "$img" ansible-playbook -i localhost, -c local /runner/t/ping.yml
echo "== $fam ok"
