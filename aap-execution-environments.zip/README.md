# aap-execution-environments

Los 4 Execution Environments (EE) de AAP, uno por familia de despliegue. Se construyen con
`ansible-builder` + **podman** en runners de GitHub y se publican en **Artifactory**. AAP los baja de ahí.

| Familia | Imagen | Para qué |
|---|---|---|
| linux | `ee-linux` | WAS/Liberty, WebLogic, TIBCO, copias, Kafka y bases de datos (Oracle, MSSQL, Teradata, Mongo con drivers de Python) |
| openshift | `ee-openshift` | java_container, configMap, multi-instancia, node, python (kubernetes.core + `oc`) |
| api | `ee-api` | Avoka, Flink y lo que se despliega llamando a una API |
| windows | `ee-windows` | binarios de proveedor, IIS y servicios por WinRM/PSRP |

Cada familia publica dos imágenes con la misma versión:
- `ee-<familia>:<versión>` → la que usa AAP.
- `ee-<familia>-ci:<versión>` → la misma + ansible-lint, yamllint y pytest, para el CI de `deploy-playbooks`.

## Estructura

```
ee/<familia>/execution-environment.yml   definición (ansible-builder v3)
ee/<familia>/requirements.yml            collections
ee/<familia>/requirements.txt            librerías de Python
ee/<familia>/bindep.txt                  paquetes del sistema
ee/versions.yml                          versión (= tag) de cada EE
ci/Containerfile.ci                      imagen de CI = EE + herramientas de revisión
tests/expect.yml, tests/smoke.sh         qué tiene que traer cada EE y la prueba que lo revisa
tests/changed.py                         qué familias cambiaron
tests/check_versions.py                  si cambió un EE, su versión tiene que subir
.github/workflows/build.yml              el pipeline
aap-config/execution_environments.yml    lo que va en el repo aap-config (credencial + 4 EE en AAP)
```

## El pipeline

- **PR:** revisa que la versión haya subido si cambió un EE. Construye y prueba **solo las familias que cambiaron**. No publica nada.
- **main:** construye, prueba y publica en Artifactory. Si el tag ya existe, no lo sobrescribe.
- **Manual (workflow_dispatch):** reconstruye una familia o las 4.

## Cómo sacar una versión nueva

1. Cambia lo que necesites en `ee/<familia>/` (por ejemplo, agregar una collection).
2. Sube su versión en `ee/versions.yml` (`1.0.0` → `1.1.0`).
3. Abre el PR. El CI construye y prueba. Merge.
4. main publica `ee-<familia>:1.1.0`.
5. En `aap-config` cambia el tag del EE y en `deploy-playbooks/ee/versions.yml` el de la imagen de CI.

## Todo sale de Artifactory

Nada se baja directo de internet. Cada cosa sale de un repo de Artifactory:

| Qué | Repo de Artifactory (tipo) | Proxy de | Variable |
|---|---|---|---|
| Imagen base `ee-minimal-rhel9` | Docker **remote** | `registry.redhat.io` | `ARTIFACTORY_REDHAT_REPO` |
| Librerías de Python (pip) | PyPI **remote** | `pypi.org` | `ARTIFACTORY_PYPI_REPO` |
| Collections (ansible-galaxy) | Ansible **remote** | `galaxy.ansible.com` | `ARTIFACTORY_ANSIBLE_REPO` |
| Paquetes del sistema (microdnf) | RPM **remote** ×2 | UBI 9 BaseOS y AppStream (`cdn-ubi.redhat.com/content/public/ubi/dist/ubi9/9/x86_64/{baseos,appstream}/os/`) | `ARTIFACTORY_UBI_BASEOS_REPO`, `ARTIFACTORY_UBI_APPSTREAM_REPO` |
| Cliente `oc` / `kubectl` | Generic **remote** | `https://mirror.openshift.com/pub/openshift-v4/` | `ARTIFACTORY_GENERIC_REPO` |
| Destino de los EE | Docker **local** | — | `ARTIFACTORY_DOCKER_REPO` |

**Las credenciales no quedan en la imagen.** El pipeline arma `pip.conf`, `ansible.cfg`, `artifactory.repo` y `netrc`
en una carpeta temporal del runner y la monta en `/run/build-secrets` solo mientras construye
(`--extra-build-cli-args "-v …:/run/build-secrets:ro"`). La imagen final no trae esos archivos, y antes de publicar
el pipeline revisa que el token no aparezca en el historial de la imagen.

## Probar en local

Arma la carpeta de credenciales igual que el paso «Credenciales de build» del workflow (en `~/build-secrets`) y:

```bash
pip install ansible-builder
podman login <artifactory>
ansible-builder build -f ee/linux/execution-environment.yml -t ee-linux:dev \
  --build-arg EE_BASE_IMAGE=<artifactory>/<remote-redhat>/ansible-automation-platform-25/ee-minimal-rhel9:latest \
  --extra-build-cli-args="-v $HOME/build-secrets:/run/build-secrets:ro,Z"
bash tests/smoke.sh linux ee-linux:dev
```

## Credenciales

### En GitHub (Settings → Secrets and variables → Actions)

**Secrets** (dos cuentas de servicio de Artifactory):

| Nombre | Permiso | Para qué |
|---|---|---|
| `ARTIFACTORY_READ_USER` / `ARTIFACTORY_READ_TOKEN` | **lectura** en los repos remote (Docker de Red Hat, PyPI, Ansible, RPM, Generic) | construir: imagen base, pip, galaxy, microdnf, oc |
| `ARTIFACTORY_PUSH_USER` / `ARTIFACTORY_PUSH_TOKEN` | **escritura solo** en `ARTIFACTORY_DOCKER_REPO` | publicar los EE (solo en main) |

**Variables:**

| Nombre | Ejemplo |
|---|---|
| `ARTIFACTORY_HOST` | `artifactory.banco.com` |
| `ARTIFACTORY_DOCKER_REPO` | `aap-ee-docker-local` |
| `ARTIFACTORY_REDHAT_REPO` | `registry-redhat-remote` |
| `ARTIFACTORY_PYPI_REPO` | `pypi-remote` |
| `ARTIFACTORY_ANSIBLE_REPO` | `ansible-galaxy-remote` |
| `ARTIFACTORY_UBI_BASEOS_REPO` / `ARTIFACTORY_UBI_APPSTREAM_REPO` | `ubi9-baseos-remote` / `ubi9-appstream-remote` |
| `ARTIFACTORY_GENERIC_REPO` | `openshift-mirror-remote` |
| `EE_BASE_TAG` (opcional) | tag de `ee-minimal-rhel9`; por defecto `latest` (mejor fijarlo) |
| `OC_VERSION` (opcional) | por defecto `4.14.40` |

No hace falta ninguna credencial de Red Hat ni de AAP en GitHub: la de Red Hat la tiene el remote de Artifactory, y GitHub nunca habla con AAP.

### En AAP (van en el repo aap-config, valores en Vault)

| Qué | Para qué |
|---|---|
| Credencial *Container Registry* `artifactory-ee-pull` | host de Artifactory + cuenta de **solo lectura** sobre `ARTIFACTORY_DOCKER_REPO`. AAP la usa para bajar los EE |
